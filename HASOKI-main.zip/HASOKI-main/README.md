<div align=center>
<p align="center"><img src="https://www.linkpicture.com/q/hasoki.jpg" width="800px" height="200px" alt="ddos"></p>
 <p>
 <img src="https://img.shields.io/github/stars/cutipu/HASOKI?color=%23DF0067&style=for-the-badge"/> &nbsp;
 <img src="https://img.shields.io/github/forks/cutipu/HASOKI?color=%239999FF&style=for-the-badge"/> &nbsp;
  <a href="#"><img alt="Hasoki last commit (main)" src="https://img.shields.io/github/last-commit/cutipu/HASOKI/main?color=green&style=for-the-badge"></a>
 <a href="https://github.com/cutipu/HASOKI/issues"><img alt="MatrixTM issues" src="https://img.shields.io/github/issues/cutipu/HASOKI?color=purple&style=for-the-badge"></a>
   <img src="https://img.shields.io/github/license/cutipu/HASOKI?color=%23E8E8E8&style=for-the-badge"/> &nbsp;
</p>
 DDoS Attack Panel includes CloudFlare Bypass (UAM, CAPTCHA, GS ,VS ,BFM, etc..)<br/><br/>
 This is open source code. I am not responsible if you use it for malicious attacks!
<p align="center"><img src="https://www.linkpicture.com/q/yaso1_1.png"width="600px" height="500px" alt="ddos"></p>
</div>

```sh
- [x] Add auto download fresh socks5 after attack with method sky and slowloris
- [x] Add HTTP/2 (HTTPX) method
- [x] Add bypass method [STRONG ATTACK]
- [x] Add spoof method [STRONG ATTACK]
- [x] Change pxcfb to TSL1.3 Proxy Flood 
- [x] Add HULK - HTTP Unbearable Load King
- [x] Add pxHULK - proxy HTTP Unbearable Load King
 
```
<div align=center>
 <img src="https://img.shields.io/badge/Python-FFDD00?style=for-the-badge&logo=python&logoColor=blue"/></br>
</div>

## Menu
![hasoki](https://www.linkpicture.com/q/Screenshot-153_1.png)
## Methods

```sh
  [Layer 7]
 - spoof | STRONG ATTACK with spoof Header X-ForWard
 - http2 | HTTP/2 attack with proxy [httpx]
 - cfb   | Bypass CF attack
 - pxcfb | Bypass CF attack tsl1.3 with proxy [fixed work]
 - cfpro | Bypass CF UAM(Under Attack Mode), CAPTCHA, BFM(Bot Fight Mode) etc.. (request)
 - cfsoc | Bypass CF UAM(Under Attack Mode), CAPTCHA, BFM(Bot Fight Mode) etc.. (socket)
 - bypass| Bypass Google Project Shield, Vshield etc.. (socket)
 - raw   | Request Attack
 - post  | Post Request Attack
 - head  | Head Request Attack
 - soc   | Socket Attack
 - hulk  | HTTP Unbearable Load King
 - hulk  | proxy hulk HTTP Unbearable Load King
 - sky   | HTTPS Flood and bypass for CF NoSec, DDoS Guard Free and vShield (SOCKS5)
 -stellar| HTTPS Sky method without proxies
 - pxraw | Proxy Request Attack
 - pxsoc | Proxy Socket Attack
 - pxslow| slowloris Attack (SOCKS5)
 
  [Layer 4]
  -udp | simple udp flood
  -tcp | simple tcp syn flood <work fine ! >
  -vse | Send Valve Source Engine Protocol
  -mine| minecraft dos attack
  
  [Tools]
 - Dns        | Classic DNS Lookup
 - Geoip      | Geo IP Address Lookup
 - Subnet     | Subnet IP Address Lookup
 
 - Next Update SLOWREAD method (SOON...)
```

## Usage
```sh
You must use Python 3.9 or higher
DOWNLOAD:  git clone https://github.com/cutipu/HASOKI.git
INSTALL: - python setup.py install or python3 setup.py install
         - with pip:
           pip3 install -r requirements.txt  or  pip install -r requirements.txt
NOTICE: For bypass work need install lastest verion Chrome
 - wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
 - apt-get install ./google-chrome-stable_current_amd64.deb
 Thread set 10-50 > work
```

## Contact Developer
```sh
 Buy Me a Coffee BTC: 34zoKEUcZ42mKEUc1gB836k9puQ1MiugNr
 LEAKS https://t.me/hackingleak
 Dev : https://t.me/rebychubx
```

